import { Login } from "../features/auth/components/Login";

function LoginPage(){
    return(
        <Login></Login>
    )
}

export default LoginPage;